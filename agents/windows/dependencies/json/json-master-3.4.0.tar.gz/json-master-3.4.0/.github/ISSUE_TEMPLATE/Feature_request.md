---
name: Feature request
about: Suggest an idea for this project

---

- Describe the feature in as much detail as possible.

- Include sample usage where appropriate.
