

try:
    import os.path
except ImportError:
    pass

import os

def function(self):
    import sys


if a == b:
    import sys

def function2(self):
    if a == b:
        import platform

def function3(self):
    import platform
    import email


import email
