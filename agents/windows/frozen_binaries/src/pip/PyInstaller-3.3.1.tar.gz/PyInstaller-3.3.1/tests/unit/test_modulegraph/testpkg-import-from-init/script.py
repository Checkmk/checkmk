import pkg.subpkg
import pkg2.subpkg
