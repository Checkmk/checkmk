""" nspkg.module """
