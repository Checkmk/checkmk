import mod1
import sys

def testme():
    global bar
    bar = 42
