""" pkg2.subpkg._collections """

A, B = "A", "B"
