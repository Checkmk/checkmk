
async def foo():
    yield 1
