See https://github.com/KeyWeeUsr/python-dis3 for details.


