from setuptools import setup

setup(
    name='pypiwin32',
    version='223',
    install_requires='pywin32>=223',
)