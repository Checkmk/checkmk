Limited description of the content:
lwa_enable.cmd - stop&disable new agent + enable& start old one
wnx_enable.cmd - stop&disable old agent + enable& start new one