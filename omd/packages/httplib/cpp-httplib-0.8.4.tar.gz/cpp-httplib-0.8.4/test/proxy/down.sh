docker-compose down --rmi all
