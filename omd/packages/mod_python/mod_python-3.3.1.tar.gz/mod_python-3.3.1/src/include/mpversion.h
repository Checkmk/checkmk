#define MPV_MAJOR 3
#define MPV_MINOR 3
#define MPV_PATCH 1
#define MPV_BUILD 20070129
#define MPV_STRING "3.3.1"
