#ifndef WARN_H
extern void warn(const char *fmt, ...);
#endif
