/* Stub for base/notifications.c */
int service_notification(service *svc, int type, char *not_author, char *not_data, int options) {}
int host_notification(host *hst, int type, char *not_author, char *not_data, int options) {}
