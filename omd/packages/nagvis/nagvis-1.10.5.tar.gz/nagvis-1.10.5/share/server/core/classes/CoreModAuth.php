<?php

/*****************************************************************************
 *
 * CoreModAuth.php - This module handles the user login and logout
 *
 * Copyright (c) 2004-2016 NagVis Project (Contact: info@nagvis.org)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *****************************************************************************/

/**
 * @author  Lars Michelsen <lm@larsmichelsen.com>
 */
class CoreModAuth extends CoreModule
{
    /** @var GlobalCore */
    protected $CORE;

    /** @var CoreRequestHandler */
    protected $FHANDLER;

    /**
     * @param GlobalCore $CORE
     */
    public function __construct($CORE)
    {
        $this->sName = 'Auth';
        $this->CORE = $CORE;

        $this->aActions = [
            'login' => !REQUIRES_AUTHORISATION,
                                'logout' => REQUIRES_AUTHORISATION
        ];

        $this->FHANDLER = new CoreRequestHandler($_POST);
    }

    /**
     * @param bool $printErr
     * @return void
     */
    public function check($printErr)
    {

    }

    /**
     * @return true|void
     * @throws NagVisException
     */
    public function handleAction()
    {
        global $AUTH;
        if ($this->offersAction($this->sAction)) {
            if ($this->sAction == 'logout') {
                if ($AUTH->logout()) {
                    return true;
                } else {
                    throw new NagVisException(
                        l('Unable to log you out. Maybe it is not supported by your authentication module.'),
                        null,
                        1,
                        cfg('paths', 'htmlbase')
                    );
                }
            }
        }
    }

    /**
     * @return array|false
     * @throws UserInputError
     */
    private function handleResponseAuth()
    {
        $attr = [
            'username' => MATCH_USER_NAME,
            'password' => null
        ];
        $this->verifyValuesSet($this->FHANDLER, $attr);
        $this->verifyValuesMatch($this->FHANDLER, $attr);

        // Check length limits
        $bValid = true;
        if ($this->FHANDLER->isLongerThan('username', AUTH_MAX_USERNAME_LENGTH)) {
            $bValid = false;
        }
        if ($bValid && $this->FHANDLER->isLongerThan('password', AUTH_MAX_PASSWORD_LENGTH)) {
            $bValid = false;
        }

        //@todo Escape vars?

        // Store response data
        if ($bValid) {
            return [
                'user' => $this->FHANDLER->get('username'),
                'password' => $this->FHANDLER->get('password')
            ];
        } else {
            return false;
        }
    }

    /**
     * @return void
     * @throws NagVisException
     */
    public function msgAlreadyLoggedIn()
    {
        throw new NagVisException(
            l('You are already logged in. You will be redirected.'),
            null,
            1,
            cfg('paths', 'htmlbase')
        );
    }

    /**
     * @return void
     * @throws NagVisException
     */
    public function msgInvalidCredentials()
    {
        throw new NagVisException(
            l('You entered invalid credentials.'),
            l('Authentication failed'),
            1,
            CoreRequestHandler::getReferer('')
        );
    }
}
