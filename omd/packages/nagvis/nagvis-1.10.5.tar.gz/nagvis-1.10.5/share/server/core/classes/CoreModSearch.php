<?php

/*******************************************************************************
 *
 * CoreModSearch.php - Core module to display the map object search dialog
 *
 * Copyright (c) 2004-2016 NagVis Project (Contact: info@nagvis.org)
 *
 * License:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 ******************************************************************************/

/**
 * @author Lars Michelsen <lm@larsmichelsen.com>
 */
class CoreModSearch extends CoreModule
{
    /** @var GlobalCore */
    protected $CORE;

    /**
     * @param GlobalCore $CORE
     */
    public function __construct($CORE)
    {
        $this->sName = 'Search';
        $this->CORE = $CORE;

        $this->aActions = ['view' => REQUIRES_AUTHORISATION];
    }

    /**
     * @return false|string
     */
    public function handleAction()
    {
        global $AUTH;
        $sReturn = '';

        if ($this->offersAction($this->sAction)) {
            if ($this->sAction == 'view') {
                // Check if user is already authenticated
                if ($AUTH->isAuthenticated()) {
                    $VIEW = new ViewSearch();
                    $sReturn = json_encode(['code' => $VIEW->parse()]);
                } else {
                    $sReturn = '';
                }
            }
        }

        return $sReturn;
    }
}
