/*
 * module to include the modules
 */

config_require(if-mib/ifTable/ifTable)
