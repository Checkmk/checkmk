void init_hw_sensors( void );
void shutdown_hw_sensors( void );
