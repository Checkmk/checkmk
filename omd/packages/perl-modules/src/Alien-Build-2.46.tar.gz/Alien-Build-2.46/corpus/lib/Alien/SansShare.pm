package Alien::SansShare;

use strict;
use warnings;
use parent qw( Alien::Base );

1;
