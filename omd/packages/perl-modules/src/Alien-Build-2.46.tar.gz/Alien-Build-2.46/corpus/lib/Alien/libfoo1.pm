package Alien::libfoo1;

use strict;
use warnings;
use parent qw( Alien::Base );

sub alien_helper
{
  return {
    foo1 => sub { 'bar' . (1+2) },
    foo2 => '"baz" . (3+4)',
  };
}

1;
