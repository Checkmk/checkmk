package Foo::Bar::Baz;

use strict;
use warnings;

our $VERSION = '1.23';

1;
