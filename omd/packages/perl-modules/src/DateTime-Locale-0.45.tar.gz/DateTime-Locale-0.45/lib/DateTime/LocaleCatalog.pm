
=pod

=head1 NAME

DateTime::LocaleCatalog - renamed to DateTime::Locale::Catalog

=head1 DESCRIPTION

This module has been renamed to L<DateTime::Locale::Catalog>

=cut
