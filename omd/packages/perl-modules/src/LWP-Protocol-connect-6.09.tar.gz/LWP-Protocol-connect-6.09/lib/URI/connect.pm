package URI::connect;

use strict;
use warnings;

our $VERSION = '6.09'; # VERSION

use base 'URI::http';

1;

