package Duplicated;

1;
__END__