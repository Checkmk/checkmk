package inner_diamond_N;

use inner_diamond_E;
use inner_diamond_W;

1;
__END__