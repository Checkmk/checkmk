package inner_diamond_S;

use outer_diamond_S;

1;
__END__