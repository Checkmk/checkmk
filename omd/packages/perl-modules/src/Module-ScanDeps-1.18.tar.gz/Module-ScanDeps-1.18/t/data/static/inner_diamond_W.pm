package inner_diamond_W;

use inner_diamond_S;

1;
__END__