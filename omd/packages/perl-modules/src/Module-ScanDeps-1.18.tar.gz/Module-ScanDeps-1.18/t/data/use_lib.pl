#!/usr/bin/perl

use lib "t/data/check_path_to_inc_name";
use Some;
