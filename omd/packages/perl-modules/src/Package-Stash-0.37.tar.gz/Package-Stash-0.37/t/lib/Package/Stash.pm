$Package::Stash::IMPLEMENTATION = 'PP';
do './lib/Package/Stash.pm' or die $@ || $!;
1;
