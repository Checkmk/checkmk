package E;

# This is a good class, but not a driver

use strict;

use vars qw{$VERSION};
BEGIN {
	$VERSION = '0.01';
}

sub dummy { 1 }

1;
