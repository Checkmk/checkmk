package URI::rtspu;

use strict;
use warnings;

use parent 'URI::rtsp';

sub default_port { 554 }

1;
