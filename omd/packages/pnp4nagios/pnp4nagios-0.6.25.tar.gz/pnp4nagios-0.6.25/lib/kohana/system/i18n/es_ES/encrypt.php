<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'El grupo %s no esta definidp en la configuración.',
	'requires_mcrypt'   => 'Para usar la librería de Encriptación, mcrypt debe estar habilitado.',
	'no_encryption_key' => 'Para usar la librería de Encriptación, tienes que especificar una llave de encriptación en tu archivo de configuración.',
);
