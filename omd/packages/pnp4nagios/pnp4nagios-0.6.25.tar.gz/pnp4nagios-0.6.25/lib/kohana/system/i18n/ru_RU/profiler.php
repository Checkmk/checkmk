<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Производительность',
	'post_data'    => 'Данные POST',
	'no_post'      => 'Нет данных POST',
	'session_data' => 'Данные сессии',
	'no_session'   => 'Нет данных сессии',
	'queries'      => 'Запросов к БД',
	'no_queries'   => 'Нет запросов к БД',
	'no_database'  => 'БД не загружена',
	'cookie_data'  => 'Данные cookie',
	'no_cookie'    => 'Нет данных cookie',
);
