<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'El grupo %s no esta definido en la configuracion.',
	'extension_not_loaded' => 'La extensión PHP %s tiene que estar cargada para poder utilizar este driver.',
	'unwritable'           => 'El directorio seleccionado, %s, no tiene permisos de escritura.',
	'resources'            => 'No es posible guardar el contenido en la cache, el contenido no es serializable.',
	'driver_error'         => '%s',
);