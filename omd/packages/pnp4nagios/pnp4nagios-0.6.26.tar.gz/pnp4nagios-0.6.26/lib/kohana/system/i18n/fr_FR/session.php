<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'Le nom de session "session_name", %s, est invalide. Il doit contenir uniquement des caractères alphanumériques et au moins une lettre doit être présente.',
);
