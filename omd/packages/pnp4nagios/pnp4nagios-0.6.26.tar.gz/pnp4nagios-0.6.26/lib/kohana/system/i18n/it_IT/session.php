<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'Il parametro session_name, %s, non è valido. Può contenere solo caratteri alfanumerici o il trattino basso. Almeno una lettera deve essere presente.',
);
