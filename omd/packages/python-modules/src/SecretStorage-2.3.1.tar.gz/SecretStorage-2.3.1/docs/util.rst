============================
Additional utility functions
============================

.. automodule:: secretstorage.util
   :members:
      format_secret,
      exec_prompt,
      exec_prompt_glib,
      exec_prompt_qt,
      unlock_objects
