Iter IO
=======

.. warning::
    .. deprecated:: 0.15
        This will be removed in version 1.0.

.. automodule:: werkzeug.contrib.iterio

.. autoclass:: IterIO
   :members:
