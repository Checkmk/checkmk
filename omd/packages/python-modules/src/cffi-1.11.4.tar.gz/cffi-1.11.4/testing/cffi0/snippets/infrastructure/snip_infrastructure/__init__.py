
def func():
    return 42
