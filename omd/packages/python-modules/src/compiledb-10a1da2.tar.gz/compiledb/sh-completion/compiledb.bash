eval "$(_COMPILEDB_COMPLETE=source compiledb)"
