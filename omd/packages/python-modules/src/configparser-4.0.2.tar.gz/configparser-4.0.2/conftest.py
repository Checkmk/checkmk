import sys


collect_ignore = ['src/configparser.py'] if sys.version_info > (3,) else []
