.. rst-class:: block-title

.. danger::

    **This algorithm is not considered secure by modern standards.**
    It should only be used when verifying existing hashes,
    or when interacting with applications that require this format.
    For new code, see the list of :ref:`recommended hashes <recommended-hashes>`.

