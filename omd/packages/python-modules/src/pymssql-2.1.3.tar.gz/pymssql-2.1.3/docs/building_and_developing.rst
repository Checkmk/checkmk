.. include:: ../README_building_and_developing.rst

.. Please see the `README_building_and_developing.rst` file located in the root of the pymssql source
   code tree.
