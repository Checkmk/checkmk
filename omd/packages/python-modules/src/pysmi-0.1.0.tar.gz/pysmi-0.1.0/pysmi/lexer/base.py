#
# This file is part of pysmi software.
#
# Copyright (c) 2015-2017, Ilya Etingof <etingof@gmail.com>
# License: http://pysmi.sf.net/license.html
#


class AbstractLexer(object):
    def reset(self):
        raise NotImplementedError()
