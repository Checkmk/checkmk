
.. _reader.callback.CallbackReader:

Callback reader
---------------

*CallbackReader* class instance tries to fetch MIB files by calling user object.

.. autoclass:: pysmi.reader.callback.CallbackReader
  :members:
