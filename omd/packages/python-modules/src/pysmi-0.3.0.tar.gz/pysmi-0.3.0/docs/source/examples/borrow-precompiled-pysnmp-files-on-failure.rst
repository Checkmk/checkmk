
.. include:: /../../examples/borrow-precompiled-pysnmp-files-on-failure.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/borrow-precompiled-pysnmp-files-on-failure.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/borrow-precompiled-pysnmp-files-on-failure.py>` script.

