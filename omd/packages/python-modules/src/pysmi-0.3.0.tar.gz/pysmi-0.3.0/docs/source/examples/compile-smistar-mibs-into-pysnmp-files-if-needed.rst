
.. include:: /../../examples/compile-smistar-mibs-into-pysnmp-files-if-needed.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/compile-smistar-mibs-into-pysnmp-files-if-needed.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/compile-smistar-mibs-into-pysnmp-files-if-needed.py>` script.

