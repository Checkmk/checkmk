
.. _borrower.anyfile.AnyFileBorrower:

Any file borrower
-----------------

.. autoclass:: pysmi.borrower.anyfile.AnyFileBorrower
   :members:
