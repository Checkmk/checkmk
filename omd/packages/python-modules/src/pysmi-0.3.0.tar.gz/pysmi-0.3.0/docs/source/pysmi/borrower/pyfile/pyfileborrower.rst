
.. _borrower.pyfile.PyFileBorrower:

Python file borrower
--------------------

.. autoclass:: pysmi.borrower.pyfile.PyFileBorrower
   :members:
