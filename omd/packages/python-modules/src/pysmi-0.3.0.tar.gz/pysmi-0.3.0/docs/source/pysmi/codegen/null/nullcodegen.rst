
.. _codegen.null.NullCodeGen:

Code generation stub
--------------------

.. autoclass:: pysmi.codegen.null.NullCodeGen
   :members:
