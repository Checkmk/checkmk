
.. _reader.compiler.MibStatus:

Compilation status
------------------

*MibStatus* class instance is used by :func:`MibCompiler.compiler` to
indicate the outcome of MIB transformation operation.

.. autoclass:: pysmi.compiler.MibStatus
  :members:
