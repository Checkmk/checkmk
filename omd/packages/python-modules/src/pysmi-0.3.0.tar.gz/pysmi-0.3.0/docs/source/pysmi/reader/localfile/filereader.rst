
.. _reader.localfile.FileReader:

Local file reader
-----------------

*FileReader* class instance looks up MIB files in given directories on
the host running PySMI.

.. autoclass:: pysmi.reader.localfile.FileReader
  :members:
