
.. _searcher.pypackage.PyPackageSearcher:

Search Python packages
----------------------

Some MIBs, most frequently the base ones, can be stored at a Python package.
There existence can be checked with the *PyPackageSearcher* class instances.

.. autoclass:: pysmi.searcher.pypackage.PyPackageSearcher
   :members:
