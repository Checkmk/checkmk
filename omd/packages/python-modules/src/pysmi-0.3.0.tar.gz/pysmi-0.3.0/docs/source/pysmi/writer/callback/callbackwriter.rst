
.. _writer.callback.CallbackReader:

Callback writer
---------------

*CallbackWriter* class instance passes the contents of the compiled MIB files to a user object.

.. autoclass:: pysmi.writer.callback.CallbackWriter
  :members:
