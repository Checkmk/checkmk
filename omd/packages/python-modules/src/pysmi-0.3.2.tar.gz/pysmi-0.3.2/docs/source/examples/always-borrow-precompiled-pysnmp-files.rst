
.. include:: /../../examples/always-borrow-precompiled-pysnmp-files.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/always-borrow-precompiled-pysnmp-files.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/always-borrow-precompiled-pysnmp-files.py>` script.

