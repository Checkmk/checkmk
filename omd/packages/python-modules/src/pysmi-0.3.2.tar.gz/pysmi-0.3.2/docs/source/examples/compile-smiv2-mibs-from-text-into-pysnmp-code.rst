
.. include:: /../../examples/compile-smiv2-mibs-from-text-into-pysnmp-code.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/compile-smiv2-mibs-from-text-into-pysnmp-code.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/compile-smiv2-mibs-from-text-into-pysnmp-code.py>` script.

