
.. include:: /../../examples/download-and-compile-smistar-mibs-into-pysnmp-files.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/download-and-compile-smistar-mibs-into-pysnmp-files.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/download-and-compile-smistar-mibs-into-pysnmp-files.py>` script.

