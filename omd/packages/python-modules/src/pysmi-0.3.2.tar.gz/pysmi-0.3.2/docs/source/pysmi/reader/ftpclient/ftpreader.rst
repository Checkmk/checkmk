
.. _reader.ftpclient.FtpReader:

FTP reader
----------

*FtpReader* class instance tries to download MIB files from configured FTP server.

.. autoclass:: pysmi.reader.ftpclient.FtpReader
  :members:
