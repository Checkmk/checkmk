
.. _writer.pyfile.PyFileWriter:

Python file writer
------------------

.. autoclass:: pysmi.writer.pyfile.PyFileWriter
  :members:
