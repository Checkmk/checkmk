.. toctree::
   :maxdepth: 2

Fetching variables
------------------

.. include:: /../../examples/v1arch/asyncore/manager/cmdgen/fetch-scalar-value.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v1arch/asyncore/manager/cmdgen/fetch-scalar-value.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v1arch/asyncore/manager/cmdgen/fetch-scalar-value.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
