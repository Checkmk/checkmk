This directory is a repository of .snmprec files -- those are picked by
Simulator using community name (SNMPv1/v2c) or context name (SNMPv3)
as a selector.  The contents of .snmprec files is used by Simulator
for building responses.

Simulator will report .snmprec files it finds on startup along with
community/context names to be used to address them.
