.. currentmodule:: click

.. include:: ../CHANGES.rst
