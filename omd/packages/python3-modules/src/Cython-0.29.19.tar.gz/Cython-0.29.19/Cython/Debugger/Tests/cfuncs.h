void some_c_function(void);
