from calc_mean_deco import mean

print(mean.__doc__)
