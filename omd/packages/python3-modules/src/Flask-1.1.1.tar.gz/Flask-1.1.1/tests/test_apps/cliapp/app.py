from __future__ import absolute_import
from __future__ import print_function

from flask import Flask

testapp = Flask("testapp")
