.. automodule:: werkzeug.contrib.fixers
