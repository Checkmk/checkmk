"""Werkzeug powered Teeworlds Server Browser."""
from .application import make_app
