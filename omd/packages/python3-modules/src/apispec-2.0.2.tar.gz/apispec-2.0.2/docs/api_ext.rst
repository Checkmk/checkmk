Built-in Plugins
================

apispec.ext.marshmallow
-----------------------

.. automodule:: apispec.ext.marshmallow
    :members:

apispec.ext.marshmallow.openapi
+++++++++++++++++++++++++++++++

.. automodule:: apispec.ext.marshmallow.openapi
    :members:
