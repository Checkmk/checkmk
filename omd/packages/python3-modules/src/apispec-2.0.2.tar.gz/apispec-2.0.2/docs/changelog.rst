.. seealso::
  Need help upgrading to apispec 1.0.0? Check out the :doc:`upgrading guide <upgrading>`.

.. include:: ../CHANGELOG.rst
