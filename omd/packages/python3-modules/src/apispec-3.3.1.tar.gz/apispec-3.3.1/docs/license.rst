*******
License
*******

.. literalinclude:: ../LICENSE
