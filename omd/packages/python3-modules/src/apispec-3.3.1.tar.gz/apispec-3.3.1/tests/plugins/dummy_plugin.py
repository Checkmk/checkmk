def setup(spec):
    spec.old_plugins["tests.plugins.dummy_plugin"]["foo"] = 42
