:doc:`/index`

.. _extract_label:


Extract
=======

.. automodule:: deepdiff.path

.. autofunction:: extract

Back to :doc:`/index`
