pytest --cov=deepdiff --cov-report term-missing
