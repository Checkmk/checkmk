Changelog
---------

Here you can see the full list of changes between each Inflection release.

0.3.1 (May 3, 2015)
^^^^^^^^^^^^^^^^^^^

- Fixed trove classifiers not showing up on PyPI.
- Fixed "human" pluralized as "humen" and not "humans".
- Fixed "potato" pluralized as "potatos" and not "potatoes".

0.3.0 (March 1, 2015)
+++++++++++++++++++++

- Added `tableize()` function.

0.2.1 (September 3, 2014)
+++++++++++++++++++++++++

- Added Python 2, Python 3 and Python 3.4 trove classifiers.

0.2.0 (June 15, 2013)
+++++++++++++++++++++

- Added initial support for Python 3.
- Dropped Python 2.5 support.

0.1.2 (March 13, 2012)
++++++++++++++++++++++

- Added Python 2.5 support.

0.1.1 (February 24, 2012)
+++++++++++++++++++++++++

- Fixed some files not included in the distribution package.

0.1.0 (February 24, 2012)
+++++++++++++++++++++++++

- Initial public release
