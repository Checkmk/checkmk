License
=======

.. literalinclude:: ../LICENSE
