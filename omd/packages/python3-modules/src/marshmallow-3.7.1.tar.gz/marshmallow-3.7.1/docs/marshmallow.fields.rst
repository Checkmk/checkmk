.. _api_fields:

Fields
======

.. automodule:: marshmallow.fields
    :members:
    :private-members:
    :autosummary:
