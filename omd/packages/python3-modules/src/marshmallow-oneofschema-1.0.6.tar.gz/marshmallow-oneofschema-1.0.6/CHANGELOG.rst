Changelog
---------

1.0.6 (2019-07-14)
++++++++++++++++++

Bug fixes:

* Fix support for accessing parent ``context``.

Other changes:

* Drop official support for Python 2.6 and Python 3.3.

1.0.5 (2017-06-20)
++++++++++++++++++

* Report error during load if "type" value is unhashable

1.0.4 (2017-04-25)
++++++++++++++++++

* Add option to leave type field on load

1.0.3 (2016-11-04)
++++++++++++++++++

* Add support for raising errors when schema is strict
* Remove type field from data on load

1.0.2 (2016-08-11)
++++++++++++++++++

* Fix bug with ignoring "partial" constructor argument

1.0.1 (2016-08-11)
++++++++++++++++++

* Fix bug with ignoring "many" constructor argument
* Fix code example in README

1.0 (2016-03-14)
++++++++++++++++

* Initial release.
