#####################
NumPy manual contents
#####################

.. toctree::

   user/index
   reference/index
   f2py/index
   dev/index
   release
   about
   bugs
   license
   glossary
