.. index::
    single: License

License
=======

.. include:: ../../LICENSE
