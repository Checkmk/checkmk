.. PyParsing documentation master file, created by
   sphinx-quickstart on Mon Nov 19 15:06:52 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyParsing's documentation!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Release v\ |version|

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   HowToUsePyparsing
   modules
   CODE_OF_CONDUCT


Indices and tables
~~~~~~~~~~~~~~~~~~

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
