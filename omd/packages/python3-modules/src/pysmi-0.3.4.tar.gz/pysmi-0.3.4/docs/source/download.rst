
Download & Install
==================

The best way to obtain SNMP SMI library is by running `pip`:

.. code-block:: bash

   $ virtualenv venv
   $ source venv/bin/activate
   $ pip install pysmi

Alternatively, you can download the latest release from
`GitHub <https://github.com/etingof/pysmi/releases>`_
or `PyPI <https://pypi.org/project/pysmi/>`_.
