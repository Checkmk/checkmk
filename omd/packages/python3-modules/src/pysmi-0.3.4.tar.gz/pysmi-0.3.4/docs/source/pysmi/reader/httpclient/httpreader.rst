
.. _reader.httpclient.HttpReader:

HTTP reader
-----------

*HttpReader* class instance tries to download MIB files using configured URL.

.. autoclass:: pysmi.reader.httpclient.HttpReader
  :members:
