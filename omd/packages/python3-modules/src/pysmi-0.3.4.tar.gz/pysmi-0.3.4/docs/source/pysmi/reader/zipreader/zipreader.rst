
.. _reader.zipreader.ZipReader:

ZIP archive reader
------------------

*ZipReader* class instance looks up MIB files in local ZIP archive.
ZIP subdirectories and embedded ZIP archives would be traversed.

.. autoclass:: pysmi.reader.zipreader.ZipReader
  :members:
