
.. _searcher.pyfile.PyFileSearcher:

Python files searcher
---------------------

Transformed MIBs that were saved in form of Python files can be checked
with *PyFileSearcher* class instances.

.. autoclass:: pysmi.searcher.pyfile.PyFileSearcher
   :members:
