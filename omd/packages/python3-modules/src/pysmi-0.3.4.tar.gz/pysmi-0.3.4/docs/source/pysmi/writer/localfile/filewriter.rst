
.. _writer.localfile.FileWriter:

File writer
-----------

.. autoclass:: pysmi.writer.localfile.FileWriter
  :members:
