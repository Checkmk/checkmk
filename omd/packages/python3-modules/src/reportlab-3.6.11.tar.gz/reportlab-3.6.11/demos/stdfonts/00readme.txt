This lists out the standard 14 fonts
in a very plain and simple fashion.

Notably, the output is huge - it makes 
two separate text objects for each glyph.
Smarter programming would make tighter 
PDF, but more lines of Python!  
