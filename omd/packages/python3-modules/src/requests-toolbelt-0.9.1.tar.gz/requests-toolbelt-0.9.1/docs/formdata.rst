.. _formdatautils:

Utilities for Enhanced Form-Data Serialization
==============================================

.. autofunction::
    requests_toolbelt.utils.formdata.urlencode
