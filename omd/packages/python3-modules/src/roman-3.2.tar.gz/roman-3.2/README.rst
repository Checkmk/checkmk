.. image:: https://travis-ci.org/zopefoundation/roman.svg?branch=master
   :target: https://travis-ci.org/zopefoundation/roman

.. image:: https://coveralls.io/repos/github/zopefoundation/roman/badge.svg?branch=master
   :target: https://coveralls.io/github/zopefoundation/roman?branch=master

.. image:: https://img.shields.io/pypi/v/roman.svg
   :target: https://pypi.org/project/roman/
   :alt: Current version on PyPI

.. image:: https://img.shields.io/pypi/pyversions/roman.svg
   :target: https://pypi.org/project/roman/
   :alt: Supported Python versions

roman
=====

Small helper library to convert arabic to roman numerals.
