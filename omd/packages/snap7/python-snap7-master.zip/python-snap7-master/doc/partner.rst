Partner
=======

.. automodule:: snap7.partner
   :members: