[global]
logonmodule="LogonMultisite"
logon_multisite_htpasswd="/omd/sites/update_central/etc/htpasswd"
logon_multisite_secret="/omd/sites/update_central/etc/auth.secret"
logon_multisite_serials="/omd/sites/update_central/etc/auth.serials"
logon_multisite_cookie_version=1
