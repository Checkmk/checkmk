unsigned int rrd_strtodbl(const char * str, char ** endptr, double * dbl, const char * error);
double rrd_strtod(const char *str, char **endptr);
